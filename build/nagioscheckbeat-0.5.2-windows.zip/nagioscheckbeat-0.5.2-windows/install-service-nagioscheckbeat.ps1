# delete service if it already exists
if (Get-Service nagioscheckbeat -ErrorAction SilentlyContinue) {
  $service = Get-WmiObject -Class Win32_Service -Filter "name='nagioscheckbeat'"
  $service.StopService()
  Start-Sleep -s 1
  $service.delete()
}

$workdir = Split-Path $MyInvocation.MyCommand.Path

# create new service
New-Service -name nagioscheckbeat `
  -displayName nagioscheckbeat `
  -binaryPathName "`"$workdir\\nagioscheckbeat.exe`" -c `"$workdir\\nagioscheckbeat.yml`""
